addpath('C:\Users\Francois\Documents\Hiver 2017\GELE3700 - Projet GE 1\Fichiers\Matlab\queryMySQL');

data = requeteSQL();
